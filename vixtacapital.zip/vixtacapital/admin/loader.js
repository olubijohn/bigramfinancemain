// LOADING
window.onload = () => {
    document.querySelector(".loading").style.display = "none";
    document.querySelector(".loading-cover").style.display = "none";
}
